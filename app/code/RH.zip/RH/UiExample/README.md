Magento 2 : Create UI Component Grid and Form
В этом уроке, объясняется, как создать Grid интерфейс и форму в Magento 2. Таблица и форма являются наиболее важной частью
в разделе администратора в Magento 2.