var config = {
    map: {
        '*': {
            'order-modal': 'Order_Cancel/js/order-modal'
        }
    }
};
