var config = {
    map: {
        '*': {
            'city-definition': 'City_Definition/js/city-definition'
        }
    }
};
