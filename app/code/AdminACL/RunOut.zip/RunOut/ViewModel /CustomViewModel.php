<?php
namespace AdminACL\RunOut\ViewModel;

class CustomViewModel implements \Magento\Framework\View\Element\Block\ArgumentInterface
{
    protected $stockItemRepository;
    protected $registry;

    public function __construct(
      //  \Magento\CatalogInventory\Api\StockItemRepositoryInterface $stockItemRepository,
        //\Magento\Framework\Registry  $registry
    ) {
       // $this->stockItemRepository = $stockItemRepository;
       // $this->registry = $registry;
    }


	public function getHello(){
		return 'hello1';
	} 




}
