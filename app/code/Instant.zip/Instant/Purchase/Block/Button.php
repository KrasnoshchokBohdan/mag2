<?php

namespace Instant\Purchase\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

class Button extends Template
{
//public function isEnabled()
//{
//    return true;
//}

}
