var config = {
    map: {
        '*': {
            'instant-purchase': 'Instant_Purchase/js/instant-purchase'
        }
    }
};
